# -*- coding: utf-8 -*-
"""
Created on Tue Jul 21 14:07:00 2020

@author: Christoph
"""

# Packages
import os
import uvicorn
import boto3
import re
import json
import numpy as np
import itertools
import time 
import sys
from fastapi import FastAPI, Query, Path, BackgroundTasks, Form, File, UploadFile, Body, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from pymongo import MongoClient
from bson.objectid import ObjectId
import collections

# set wd if local
# os.chdir('C:/Users/Christoph/Documents/Python Scripts/E20MP_datagovernance/e20mpcontentmoderater/app')

# import profane word list 
bad_word_list = list(np.loadtxt(r"resources/bad_word_list_E20MP.csv",delimiter=",",dtype='str'))

# Configs
API_CONFIGS = {
    'API_ENDPOINT_TEXT_UPLOAD':os.getenv('API_ENDPOINT_TEXT_UPLOAD','/text_upload_moderation'),
    'API_ENDPOINT_IMAGE_UPLOAD':os.getenv('API_ENDPOINT_IMAGE_UPLOAD','/image_upload_moderation'),
    'MONGOURI':os.getenv('MONGOURI',""),
    'MONGODBNAME':os.getenv('MONGODBNANME','E20MP'),
    'MONGOTEXTCOLNAME':os.getenv('MONGOTEXTCOLNAME','text_moderation'),
    'MONGOIMAGECOLNAME':os.getenv('MONGOTEXTMODNAME','image_moderation'),
    'AWS_KEY':os.getenv('AWS_KEY',''),
    'AWS_SECRET':os.getenv('AWS_SECRET',''),
    'AWS_REGION':os.getenv('AWS_REGION','eu-west-1'),
    }

#%% Classes with data structures
# class for Text moderation (schema)
class TextModerationReportOut(BaseModel):
    text_disintermediation_block: Optional[int]
    text_profanity_block: Optional[int]
    disintermediation_phoneno: Optional[List[str]]
    disintermediation_email: Optional[List[str]]
    disintermediation_url: Optional[List[str]]
    disintermediation_strings: Optional[List[str]]
    profanity_text: Optional[List[str]]
    
# what is written to MongoDB for Text moderation
class TextModerationtoMongo(BaseModel): 
    userId : str
    caseId : str
    timestamp : str
    reviewDecision: str
    text_moderation_report: TextModerationReportOut

# what is written to MongoDB for Image moderation
class ImageModerationtoMongo(BaseModel):
    userId : str
    caseId: str
    timestamp : str
    reviewDecision: str
    block_image_upload: int
    image_conent_block: int
    text_detected: int
    text_content_block: int
    image_moderation_report: Dict[str,float]
    image_labels_report: Dict[str,float]
    text_moderation_report: Optional[TextModerationReportOut]

# class for output of text moderation API
class contentmoderatorresponse_text(BaseModel):
    blockupload : int

# class for output of image moderation API
class contentmoderatorresponse_image(BaseModel):
    blockupload : int  
    image_labels: Dict[str,float]

#%% Meta data for documentation
tags_metadata = [
    {
     "name": 'Text Moderation',
     "title": "Text Moderation",
     "description": "API for moderating text uploaded by user",
    },
    {
        "name": "Image Moderation",
        "title": "Image Moderation and Label",
        "description": "API for moderating image uploaded by user, including text and object detection",
    },
    {
        "name": "Environment",
        "title": "Show environment",
        "description": "Show all defined variables in environment",
    }
]


### UNIT TESTS ###
'''
manually run: 
python content_moderation_api_configs.py
python content_moderation_functions.py
then can perform the below
'''
# moderation example - image
#photo = 'resources/image_examples/suggestive2.jpg'
#image_as_bytes = open(photo,mode='rb').read()
#image_mod_response = moderate_image(API_CONFIGS, image_as_bytes)

# moderation example - text
#example_text = 'please contact me on 123319010921 or email \
#on chris@abc.com or my web site is on facebook at \
#www.fbme.com shit 123 twat abc 8**71381091***7128&(*123'
#moderated_text = moderate_text(example_text, bad_word_list)
