# -*- coding: utf-8 -*-
"""
Created on Tue Jun 16 12:16:11 2020

@author: Christoph
"""

#%% DETECT LABELS 
'''
retrieved from call such as
labels_response = client.detect_labels(Image={'Bytes': photo_as_bytes})
'''
t[19]: 
{'Labels': [{'Name': 'Plant',
   'Confidence': 99.60285949707031,
   'Instances': [{'BoundingBox': {'Width': 0.5400139093399048,
      'Height': 0.8646153211593628,
      'Left': 0.20519325137138367,
      'Top': 0.06278470903635025},
     'Confidence': 89.5331802368164}],
   'Parents': []},
  {'Name': 'Tree',
   'Confidence': 99.42147827148438,
   'Instances': [],
   'Parents': [{'Name': 'Plant'}]},
  {'Name': 'Arecaceae',
   'Confidence': 98.87229919433594,
   'Instances': [],
   'Parents': [{'Name': 'Tree'}, {'Name': 'Plant'}]},
  {'Name': 'Palm Tree',
   'Confidence': 98.87229919433594,
   'Instances': [],
   'Parents': [{'Name': 'Tree'}, {'Name': 'Plant'}]},
  {'Name': 'Leaf',
   'Confidence': 66.61724090576172,
   'Instances': [],
   'Parents': [{'Name': 'Plant'}]}],
 'LabelModelVersion': '2.0',
 'ResponseMetadata': {'RequestId': 'a2ef0854-ac3a-475b-a799-2737b4b79ab0',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:16:47 GMT',
   'x-amzn-requestid': 'a2ef0854-ac3a-475b-a799-2737b4b79ab0',
   'content-length': '675',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}
  
#%% DETECT MODERATION LABELS 
'''
retrieved from call such as
moderation_labels_response = client.detect_moderation_labels(Image={'Bytes': photo_as_bytes})
''' 

{'ModerationLabels': [],
 'ModerationModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': '406d01be-6df9-4470-b7ea-1f610bfa24b8',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:16:48 GMT',
   'x-amzn-requestid': '406d01be-6df9-4470-b7ea-1f610bfa24b8',
   'content-length': '54',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}
  

#%% DETECT TEXT
'''
retrieved from call such as
text_response = client.detect_text(Image={'Bytes': photo_as_bytes})
''' 

{'TextDetections': [],
 'TextModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': 'ce3fd6df-97d4-4a38-b4ff-8e369b066e8a',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:16:48 GMT',
   'x-amzn-requestid': 'ce3fd6df-97d4-4a38-b4ff-8e369b066e8a',
   'content-length': '46',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}