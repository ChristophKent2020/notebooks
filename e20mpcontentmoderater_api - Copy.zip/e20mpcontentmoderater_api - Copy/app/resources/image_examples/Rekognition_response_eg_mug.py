# -*- coding: utf-8 -*-
"""
Created on Tue Jun 16 12:16:11 2020

@author: Christoph
"""

#%% DETECT LABELS 
'''
retrieved from call such as
labels_response = client.detect_labels(Image={'Bytes': photo_as_bytes})
'''
labels_response = {'Labels': [{'Name': 'Cup',
   'Confidence': 99.84601593017578,
   'Instances': [],
   'Parents': []},
  {'Name': 'Coffee Cup',
   'Confidence': 99.84601593017578,
   'Instances': [],
   'Parents': [{'Name': 'Cup'}]},
  {'Name': 'Porcelain',
   'Confidence': 89.87833404541016,
   'Instances': [],
   'Parents': [{'Name': 'Art'}, {'Name': 'Pottery'}]},
  {'Name': 'Art',
   'Confidence': 89.87833404541016,
   'Instances': [],
   'Parents': []},
  {'Name': 'Pottery',
   'Confidence': 89.87833404541016,
   'Instances': [],
   'Parents': []},
  {'Name': 'Tape',
   'Confidence': 88.0885009765625,
   'Instances': [{'BoundingBox': {'Width': 0.9260663390159607,
      'Height': 0.8210377097129822,
      'Left': 0.0056200833059847355,
      'Top': 0.07865210622549057},
     'Confidence': 88.0885009765625}],
   'Parents': []}],
 'LabelModelVersion': '2.0',
 'ResponseMetadata': {'RequestId': '6df8e10e-adeb-4186-8114-d9e579651ef7',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 17 Jun 2020 10:33:57 GMT',
   'x-amzn-requestid': '6df8e10e-adeb-4186-8114-d9e579651ef7',
   'content-length': '703',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}


#%% DETECT MODERATION LABELS 
'''
retrieved from call such as
moderation_labels_response = client.detect_moderation_labels(Image={'Bytes': photo_as_bytes})
''' 

moderation_labels_response = {'ModerationLabels': [],
 'ModerationModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': '0ac28616-ad9d-4f74-84c9-de3b8ce65f68',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 17 Jun 2020 10:37:58 GMT',
   'x-amzn-requestid': '0ac28616-ad9d-4f74-84c9-de3b8ce65f68',
   'content-length': '54',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}
  

#%% DETECT TEXT
'''
retrieved from call such as
text_response = client.detect_text(Image={'Bytes': photo_as_bytes})
''' 

text_response = {'TextDetections': [],
 'TextModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': '75420b1a-7a1b-4f0d-be74-6fed8c3ac609',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 17 Jun 2020 10:38:37 GMT',
   'x-amzn-requestid': '75420b1a-7a1b-4f0d-be74-6fed8c3ac609',
   'content-length': '46',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}

 