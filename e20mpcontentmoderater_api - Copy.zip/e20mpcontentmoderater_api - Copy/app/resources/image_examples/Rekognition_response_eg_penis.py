# -*- coding: utf-8 -*-
"""
Created on Tue Jun 16 12:16:11 2020

@author: Christoph
"""

#%% DETECT LABELS 
'''
retrieved from call such as
labels_response = client.detect_labels(Image={'Bytes': photo_as_bytes})
'''
{'Labels': [{'Name': 'Skin',
   'Confidence': 94.17084503173828,
   'Instances': [],
   'Parents': []},
  {'Name': 'Person',
   'Confidence': 90.76860046386719,
   'Instances': [{'BoundingBox': {'Width': 0.46039360761642456,
      'Height': 0.923245370388031,
      'Left': 0.07831340283155441,
      'Top': 0.005058374721556902},
     'Confidence': 90.76860046386719}],
   'Parents': []},
  {'Name': 'Human',
   'Confidence': 90.76860046386719,
   'Instances': [],
   'Parents': []},
  {'Name': 'Heel',
   'Confidence': 82.49386596679688,
   'Instances': [],
   'Parents': []},
  {'Name': 'Food',
   'Confidence': 69.5732421875,
   'Instances': [],
   'Parents': []},
  {'Name': 'Arm',
   'Confidence': 58.486942291259766,
   'Instances': [],
   'Parents': []},
  {'Name': 'Plant',
   'Confidence': 56.14107131958008,
   'Instances': [],
   'Parents': []}],
 'LabelModelVersion': '2.0',
 'ResponseMetadata': {'RequestId': '8a310f03-45bc-4d40-9f8b-4919a6860181',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:20:39 GMT',
   'x-amzn-requestid': '8a310f03-45bc-4d40-9f8b-4919a6860181',
   'content-length': '720',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}
  
  
#%% DETECT MODERATION LABELS 
'''
retrieved from call such as
moderation_labels_response = client.detect_moderation_labels(Image={'Bytes': photo_as_bytes})
''' 

{'ModerationLabels': [{'Confidence': 99.1332778930664,
   'Name': 'Explicit Nudity',
   'ParentName': ''},
  {'Confidence': 99.1332778930664,
   'Name': 'Graphic Male Nudity',
   'ParentName': 'Explicit Nudity'}],
 'ModerationModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': 'f0df9a1d-0e24-461a-8b40-92ed60b02e70',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:20:40 GMT',
   'x-amzn-requestid': 'f0df9a1d-0e24-461a-8b40-92ed60b02e70',
   'content-length': '218',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}
  

#%% DETECT TEXT
'''
retrieved from call such as
text_response = client.detect_text(Image={'Bytes': photo_as_bytes})
''' 

{'TextDetections': [],
 'TextModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': 'adaefdaa-f699-4dda-abfe-bbfe592f0ae5',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:20:41 GMT',
   'x-amzn-requestid': 'adaefdaa-f699-4dda-abfe-bbfe592f0ae5',
   'content-length': '46',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}