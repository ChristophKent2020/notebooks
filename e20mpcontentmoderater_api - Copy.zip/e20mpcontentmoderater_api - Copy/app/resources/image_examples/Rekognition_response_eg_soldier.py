# -*- coding: utf-8 -*-
"""
Created on Tue Jun 16 12:16:11 2020

@author: Christoph
"""

#%% DETECT LABELS 
'''
retrieved from call such as
labels_response = client.detect_labels(Image={'Bytes': photo_as_bytes})
'''
labels_response = {'Labels': [{'Name': 'Helmet',
   'Confidence': 99.98858642578125,
   'Instances': [{'BoundingBox': {'Width': 0.20374871790409088,
      'Height': 0.3348972201347351,
      'Left': 0.45330092310905457,
      'Top': 0.006982472725212574},
     'Confidence': 99.98858642578125}],
   'Parents': [{'Name': 'Clothing'}]},
  {'Name': 'Apparel',
   'Confidence': 99.98858642578125,
   'Instances': [],
   'Parents': []},
  {'Name': 'Clothing',
   'Confidence': 99.98858642578125,
   'Instances': [],
   'Parents': []},
  {'Name': 'Person',
   'Confidence': 99.25231170654297,
   'Instances': [{'BoundingBox': {'Width': 0.4180658757686615,
      'Height': 0.9588303565979004,
      'Left': 0.4262233376502991,
      'Top': 0.031734466552734375},
     'Confidence': 99.25231170654297},
    {'BoundingBox': {'Width': 0.25408515334129333,
      'Height': 0.83538419008255,
      'Left': 0.7452125549316406,
      'Top': 0.15031325817108154},
     'Confidence': 84.85724639892578}],
   'Parents': []},
  {'Name': 'Human',
   'Confidence': 99.25231170654297,
   'Instances': [],
   'Parents': []},
  {'Name': 'Military',
   'Confidence': 97.43839263916016,
   'Instances': [],
   'Parents': []},
  {'Name': 'Military Uniform',
   'Confidence': 97.43839263916016,
   'Instances': [],
   'Parents': [{'Name': 'Military'}]},
  {'Name': 'Army',
   'Confidence': 95.48873901367188,
   'Instances': [],
   'Parents': [{'Name': 'Military'},
    {'Name': 'Person'},
    {'Name': 'Military Uniform'},
    {'Name': 'Armored'}]},
  {'Name': 'Armored',
   'Confidence': 95.48873901367188,
   'Instances': [],
   'Parents': []},
  {'Name': 'People',
   'Confidence': 82.51404571533203,
   'Instances': [],
   'Parents': [{'Name': 'Person'}]},
  {'Name': 'Soldier',
   'Confidence': 76.52268981933594,
   'Instances': [],
   'Parents': [{'Name': 'Military'},
    {'Name': 'Person'},
    {'Name': 'Military Uniform'}]},
  {'Name': 'Weaponry',
   'Confidence': 76.3983154296875,
   'Instances': [],
   'Parents': []},
  {'Name': 'Weapon',
   'Confidence': 76.3983154296875,
   'Instances': [],
   'Parents': []},
  {'Name': 'Troop',
   'Confidence': 69.2525863647461,
   'Instances': [],
   'Parents': [{'Name': 'Military'},
    {'Name': 'Person'},
    {'Name': 'Military Uniform'},
    {'Name': 'Army'},
    {'Name': 'People'},
    {'Name': 'Armored'}]}],
 'LabelModelVersion': '2.0',
 'ResponseMetadata': {'RequestId': 'dbc61764-469d-4420-88a4-70e1a145cda5',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:13:44 GMT',
   'x-amzn-requestid': 'dbc61764-469d-4420-88a4-70e1a145cda5',
   'content-length': '1919',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}
  
#%% DETECT MODERATION LABELS 
'''
retrieved from call such as
moderation_labels_response = client.detect_moderation_labels(Image={'Bytes': photo_as_bytes})
''' 

{'ModerationLabels': [{'Confidence': 97.45539093017578,
   'Name': 'Violence',
   'ParentName': ''},
  {'Confidence': 97.45539093017578,
   'Name': 'Weapon Violence',
   'ParentName': 'Violence'}],
 'ModerationModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': '896643cd-2300-4d43-b34e-f905bde932c5',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:13:46 GMT',
   'x-amzn-requestid': '896643cd-2300-4d43-b34e-f905bde932c5',
   'content-length': '202',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}
  

#%% DETECT TEXT
'''
retrieved from call such as
text_response = client.detect_text(Image={'Bytes': photo_as_bytes})
''' 

{'TextDetections': [],
 'TextModelVersion': '3.0',
 'ResponseMetadata': {'RequestId': '3653bab3-a9af-493d-9ef4-3a566919c86b',
  'HTTPStatusCode': 200,
  'HTTPHeaders': {'content-type': 'application/x-amz-json-1.1',
   'date': 'Wed, 24 Jun 2020 09:13:47 GMT',
   'x-amzn-requestid': '3653bab3-a9af-493d-9ef4-3a566919c86b',
   'content-length': '46',
   'connection': 'keep-alive'},
  'RetryAttempts': 0}}