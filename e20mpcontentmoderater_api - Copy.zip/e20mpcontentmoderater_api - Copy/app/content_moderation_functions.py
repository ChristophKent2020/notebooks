# -*- coding: utf-8 -*-
"""
Created on Tue Jul 21 00:31:59 2020

@author: Christoph
"""

# Packages
from content_moderation_api_configs import *

# Image moderation
def moderate_image(API_CONFIGS, image_as_bytes):
    # initiate 'block' variables for final reporting
    block_image_upload = 0 
    image_content_block = 0
    
    # set up boto3 client to access rekognition service
    client = boto3.client(
        # service - rekognition
        'rekognition',
        # pull aws credentials from API config
        aws_access_key_id = API_CONFIGS['AWS_KEY'],
        aws_secret_access_key = API_CONFIGS['AWS_SECRET'],
        region_name = API_CONFIGS['AWS_REGION']
    )
    
    # detect lables (objects) in image
    image_labels_response = client.detect_labels(
            Image={'Bytes': image_as_bytes}
            )
    image_labels_extracted = {i['Name']:round(i['Confidence'],2) \
                               for i in image_labels_response['Labels']}
    
    # moderation of image
    image_mod_response = client.detect_moderation_labels(
            Image={'Bytes': image_as_bytes}
            )
    image_mod_extracted = {i['Name']:round(i['Confidence'],2) \
                             for i in image_mod_response['ModerationLabels']}
    # update block upload if moderation is recommended
    if len(image_mod_extracted) > 0: image_content_block = 1
    
    # extract text from image
    # - aws - #
    image_text_response = client.detect_text(
            Image={'Bytes': image_as_bytes}
            )
    image_text_extracted = ' '.join([(i['DetectedText'].upper()) \
                                for i in image_text_response['TextDetections']])


#    # moderate text extracted from image, if exists, esle set report to None
    if len(image_text_extracted) > 0:
        image_text_moderated = moderate_text(image_text_extracted, bad_word_list)
    else:
        image_text_moderated = {
                'text_content_block': 0,
                'text_detected': 0,
                'text_moderation_report': {}
                }
        
    # block image upload? 
    if ((image_content_block == 1) \
        or (image_text_moderated['text_content_block'] == 1)):
        block_image_upload = 1
    
    # build json body for final report
    image_moderation_report = {
        'block_image_upload':block_image_upload,
        'image_conent_block':image_content_block,
        'text_detected':image_text_moderated['text_detected'],
        'text_content_block': image_text_moderated['text_content_block'],
        'image_moderation_report':image_mod_extracted,
        'image_labels_report':image_labels_extracted,
        'text_moderation_report':image_text_moderated['text_moderation_report']
     }
    
    
    return(image_moderation_report)

# extract unique words from string 
def unique_list(l):
    ulist = []
    [ulist.append(x) for x in l if x not in ulist]
    return ulist


# Text moderation - disintermediation by sharing number 
def find_phone_numbers(text):
    '''
    CHECK FOR NUMBERS LIKE PHONE - NB DEVELOPMENT IN THE FUTURE MAY OVER-RIDE THIS IF 
    NARRATIVE SUGGESTS CONVERSATION REGARDING COST (E.G. HOW MUCH, AED, ETC.)
    '''
    # remove white space
    text_no_whitespace = re.sub(' ','', text)
    # remove symbols
    text_no_whitespace_or_symbols = re.sub('[^A-Za-z0-9]+', '',text)
    # regex checks
    regex_number = re.compile(r'(\d{9,})|'
            r'(\+(\d{8,}))|'
            r'([9][7][1]\d{6,})|'
            r'([0][0]\d{7})|'
            r'([0]\d{8,})', 
            re.VERBOSE|re.IGNORECASE)
    regex_number_no_symbols = re.compile(r'([9][7][1]\d{6,})|'
    r'([0][0]\d{7})|'
    r'([0]\d{8,})', 
    re.VERBOSE| re.IGNORECASE)
    regex_number_words = re.compile(r'zero|one|two|three|four|five|six|'
                                r'seven|eight|nine|ten', 
                                re.VERBOSE| re.IGNORECASE)
    regex_number_split_by_anything = re.compile(r'\d{1,2}?[^0-9]{1,2}?\d{1,2}?[^0-9]{1,2}?'
                                                r'\d{1,2}?[^0-9]{1,2}?\d{1,2}?[^0-9]{1,2}?', 
                                                re.VERBOSE | re.IGNORECASE)

    # run regex
    find_number = re.findall(regex_number, text_no_whitespace)
    find_number_no_symbols = re.findall(regex_number_no_symbols, text_no_whitespace_or_symbols)
    find_number_words = re.findall(regex_number_words, text_no_whitespace_or_symbols)
    find_number_split_up = re.findall(regex_number_split_by_anything, text_no_whitespace)
    
    # list of numbers found 
    numbers_found_unlisted = list(itertools.chain.from_iterable(find_number +
                                                            find_number_no_symbols))\
                                                            + find_number_split_up
    
    # if >= 8 words as numbers are detected, add these
    if len(find_number_words) >=8:
        numbers_found_unlisted = numbers_found_unlisted + find_number_words
        
    # get all non empty entries
    all_numbers_found = [i for i in numbers_found_unlisted if i != '']
    
    # get correct format for output    
    all_numbers_found = list(set(all_numbers_found)) if len(all_numbers_found) > 0 else []
    
    # return unique urls found
    return all_numbers_found
    
# Text moderation - disintermediation by sharing email 
def find_email(text):
    # Regex
    regex_email = re.compile(r'(\S+)?(\s+)?@(?![0-9])(?!\s+[0-9])(\s+)?(\S+)?',
                             re.VERBOSE | re.IGNORECASE)
    
    # run regex
    find_email = list(re.finditer(regex_email,text))
    
    # loop to get matches
    if len(find_email) > 0:
        all_emails_found = [i.group() for i in find_email]
    else:
        all_emails_found = []
    
    # get correct format for output    
    all_emails_found = list(set(all_emails_found)) if len(all_emails_found) > 0 else []
    
    # return unique urls found
    return all_emails_found
    
# Text moderation - disintermediation by sharing url
def find_URL(text):
    # regex
    regex_url_1 = re.compile(r'http|\.com|\.c0m|\.org|\.net|\.int|\.edu|\.gov|\.mil|www\.|'
                             r'ww\.|://|dotcom|dotc0m|dotbiz|dotnet''', 
                             re.VERBOSE | re.IGNORECASE)
    regex_url_2 = re.compile(r'^(((ht|f)tp(s?))\://)?(www.?|[a-zA-Z].)[a-zA-Z0-9\-\.]+'
                             r'\.(com|edu|gov|mil|net|org|biz|info|name|museum|us|ca|uk)(\:[0-9]+)'
                             r'*(/($|[a-zA-Z0-9\.\,\;\?\'\\\+&amp;%\$#\=~_\-]+))*$', 
                             re.VERBOSE | re.IGNORECASE)

    # run regex
    find_url_1 = list(re.finditer(regex_url_1,text))
    find_url_2 = list(re.finditer(regex_url_2,text))
    find_url_all = find_url_1 + find_url_2

    # loop to get matches
    if len(find_url_all) > 0:
        all_urls_found = [i.group() for i in find_url_all]
    else:
        all_urls_found = []
    
    # get correct format for output    
    all_urls_found = list(set(all_urls_found)) if len(all_urls_found) > 0 else []
    
    # return unique urls found
    return all_urls_found


# Text moderation - disintermediation by string-based detection 
def find_disintermediation_strings(text):
    # remove white space and symbols
    text_no_whitespace_or_symbols = re.sub('[^A-Za-z0-9]+', '',text)
    
    # find strings which indicate disintermediation 
    regex_dis_text = re.compile(r'whatsapp|watsapp|whatsap|watsap|'
            r'facebook|fcebook|fbook|facebk|faceb|fcebk|'
            r'website|url|link|lnk|address|adress|addres|adrs|addrs|'
            r'textmessage|txtmessage|textme|sms|txt|'
            r'phonenumber|phoneno|fonenumber|phone|fone|phne|'
            r'mobilenumber|mobileno|mbilenumber|mbileno|mobno|mobnumber|'
            r'cellnumber|cellphone|cellno|contactme|contact|ringme|telephone|email|mail', 
            re.VERBOSE | re.IGNORECASE)

    # run regex
    all_dis_text_detections = list(set(re.findall(regex_dis_text, text_no_whitespace_or_symbols)))
    # get correct format for output    
    all_dis_text_detections = [] if len(all_dis_text_detections) == 0 else all_dis_text_detections
    # return unique detections     
    return all_dis_text_detections

# Text moderation - profanity
def find_profanity(text, bad_word_list):
    profanity_matches = {x for x in bad_word_list if x in text.upper().split()}    
    profanity_matches = [] if len(profanity_matches) == 0 else list(profanity_matches)
    return profanity_matches

# Text moderation - combination of all disintermediation and profanity 
def moderate_text(text_for_moderation, bad_word_list):
    # initiate block variables for final reporting
    disintermediation_block = 0
    profanity_block = 0
    text_content_block = 0
    text_detected = 0    
    if len(text_for_moderation) > 0:
        text_detected = 1

    # perform moderation (as per functions above)
    phone_number_detection = find_phone_numbers(text_for_moderation)
    email_detection = find_email(text_for_moderation)
    url_detection = find_URL(text_for_moderation)
    disinter_string_detection = find_disintermediation_strings(text_for_moderation)
    profanity_detection = find_profanity(text_for_moderation, bad_word_list)
    
    # updated block vairbales for final reporting 
    if ((len(phone_number_detection) > 0) or
        (len(email_detection) > 0) or
        (len(url_detection) > 0) or
        (len(disinter_string_detection) > 0)):
        disintermediation_block = 1
    
    if len(profanity_detection) > 0:
        profanity_block = 1

    if (disintermediation_block == 1) or (profanity_block == 1):
        text_content_block = 1


    # join all
    text_moderated = {
            'text_content_block': text_content_block,
            'text_detected': text_detected,
            'text_moderation_report': {'text_disintermediation_block':disintermediation_block,
            'text_profanity_block':profanity_block,
            'disintermediation_phoneno':phone_number_detection,
            'disintermediation_email':email_detection,
            'disintermediation_url':url_detection,
            'disintermediation_strings':disinter_string_detection,
            'profanity_text':profanity_detection}
            }
            
    #return
    return(text_moderated)
    
# function to write moderation to database if flagged, this is as a background task
def write_moderation_to_DB(to_write, 
                           mongouri,
                           db_name,
                           collection):
        with MongoClient(mongouri) as client:
            db = client[db_name]
            user_collection = db[collection]
            a = user_collection.insert_one(to_write.copy()) # write copy so doesn't overwrite var
            
        return str(a.inserted_id)
    
    
    