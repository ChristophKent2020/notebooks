# -*- coding: utf-8 -*-
"""
Created on Tue Jul 21 00:31:59 2020

@author: Christoph
"""

from content_moderation_api_configs import *
from content_moderation_functions import *

    
# create app
app = FastAPI(title="Content Moderation",
    description="API to moderate user uploaded content (text & images) & label images \
    image types required are JPEG and PNG",
    version="0.0.1",)
    
# Text moderation endpoint
@app.post(API_CONFIGS['API_ENDPOINT_TEXT_UPLOAD'], 
          response_model=contentmoderatorresponse_text,
          status_code=200,
          tags=['Text Moderation'])
async def Text_moderation(caseId: str, userId: str, uploaded_text : str):
    
    # run text moderation logic
    time_stamp = time.time()
    moderated_text = moderate_text(uploaded_text, bad_word_list)
    moderated_text['timestamp'] = time_stamp
    moderated_text['userId'] = userId
    moderated_text['caseId'] = caseId
    moderated_text['reviewDecision'] = 0

    # if there is moderation detected, write this to database
    if moderated_text['text_content_block'] == 1:
        del moderated_text['text_content_block'], moderated_text['text_detected']
        mongo_id = write_moderation_to_DB(to_write = moderated_text, 
                           mongouri = API_CONFIGS['MONGOURI'],
                           db_name = API_CONFIGS['MONGODBNAME'],
                           collection = API_CONFIGS['MONGOTEXTCOLNAME'])
        response = {'blockupload':1}
    else:
        response  = {'blockupload':0}
    
    # return text moderation
    return response


# Image moderation endpoint
@app.post(API_CONFIGS['API_ENDPOINT_IMAGE_UPLOAD'], 
          response_model=contentmoderatorresponse_image,
          status_code=200,
          tags=['Image Moderation'])
async def Image_moderation(userId: str = Form(..., min_length=1),
                           caseId: str = Form(..., min_length=1),
                           uploaded_image : UploadFile = File(...)):
    # run image moderation logic
    time_stamp = time.time()
    #image_as_bytes = open('resources/image_examples/flowers_toobigerror.jpg', "rb").read()
    image_as_bytes = await uploaded_image.read()
    
    # if image is too large to be processed by Rekognition (> 5242880 bytes), return error:
    if len(image_as_bytes) > 5242880:
        raise HTTPException(status_code=400, detail="Image cannot be > 5MB, please reduce size")
        
    moderated_image = moderate_image(API_CONFIGS, image_as_bytes)
    moderated_image['timestamp'] = time_stamp
    moderated_image['userId'] = userId
    moderated_image['caseId'] = caseId
    moderated_image['reviewDecision'] = 0

    # get top 5 confidence image lables 
    #im_object_list = list(collections.OrderedDict(moderated_image['image_labels_report']).keys())[0:5]

    # if there is moderation detected, write this to database
    if moderated_image['block_image_upload'] == 1:
        mongo_id = write_moderation_to_DB(to_write = moderated_image, 
                           mongouri = API_CONFIGS['MONGOURI'],
                           db_name = API_CONFIGS['MONGODBNAME'],
                           collection = API_CONFIGS['MONGOIMAGECOLNAME'])
        response = {'blockupload':1,
            'image_labels':moderated_image['image_labels_report']}
    else:
        response = {'blockupload':0,
            'image_labels': moderated_image['image_labels_report']}

    # return image moderation
    return response

# check api environment
@app.get('/showenviron', tags = ['Environment'])
def show_environ():
    return os.environ

