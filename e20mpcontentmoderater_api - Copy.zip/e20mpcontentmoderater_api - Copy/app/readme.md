# API to moderate user uploaded content (text & images) & label images
(1) text moderation - any text is supported
endpoint = /text_upload_modetation

(2) image moderation  - API for moderating image uploaded by user, including text and object detection 
endpoint = /image_upload_moderation

to run: execute line in startup in console (i.e. $uvicorn main:app --host 0.0.0.0 --port 80)
