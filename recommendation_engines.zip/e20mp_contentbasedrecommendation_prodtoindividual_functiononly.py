# -*- coding: utf-8 -*-
"""
E20MP-contentbasedrecommendation-prodtoindividual
# Create & combine cosine similairity matrices for:
# 1) item description using TF-IDF 
# 2) item metadata soup using CountVectorizer
# user data is provided alongside all product information to find the closest 
# matches. Weighting can be provided to give each to each similarity measure 
# above, as well as how many most similar products we want to return.

"""

# import packages
import os
import pandas as pd
import numpy as np
import collections
import random
from ast import literal_eval
# for tfidf
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
# for countvectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# input directory 
input_dir = "C:/Users/Christoph/Documents/Python Scripts/E20MP_recommendation_engine/recommendation_engines/"

# read data 
## full data for comparison to after results
# import data  - for final comparison 
data = pd.read_csv(str(input_dir)+"/data/movies_metadata.csv", low_memory = False)
data_keywords = pd.read_csv(str(input_dir)+"/data/movies_keywords.csv", low_memory = False)
data_keywords.id = data_keywords.id.astype(str)
data = pd.merge(data, data_keywords, on ='id')
data.drop_duplicates('id')
data.drop_duplicates('id',inplace=True)
data = data[0:20000]

## massaged data, which is accepted by the model 
### product info (with list convertor)
product_df = pd.read_csv(str(input_dir)+'/massaged_test_data/productdf_forrecomm_prodtoindv.csv',
                         converters={'categories':eval})
product_df = product_df[~product_df['description'].isnull()]
### user info
user_df = pd.read_csv(str(input_dir)+'/massaged_test_data/userdf_forrecomm_prodtoindv.csv',
                      converters={'ids_user_blacklist':eval, 'user_interests':eval, 'user_ids_of_interest':eval})

def personalised_recommendation(product_df, user_df, desc_weight = 0.5, 
                                meta_weight= 0.5, n_prods = 20, n_cats = 5):
  '''
  # input: 
  1 - product_df with [id (str), description (str), metadata_soup (str), categories (list)] (all lower case)
  2 - user_df with [id(str), description (str), metadata_soup (str), ids_user_blacklist (list), user_interests [categories] (list), user_ids_of_interest [ids] (list)]
  3 - weight to give description-based similarity (default desc_weight = 0.5)
  4 - weight to give metadata-based similarity (default meta_weight = 0.5 )
  5 - how many most similar products to recommend to user (default n_prods = 20)
  6 - how many most similar categories to recommend to user (default n_cats = 5)

  # output:
  # dictionary with user_id, 'n_prods' recommended products, 'n_cats' recommended categories
  '''
  
  # Prepare data which is required for comparisons
  # description df (user data to match to is first row, product data is remaining rows)
  desc_df = pd.concat([user_df[['id','description']],product_df[['id','description']]])

  # metadata df (user data to match is first row, product data is reamining)
  meta_df = pd.concat([user_df[['id','metadata_soup']],product_df[['id','metadata_soup']]])

  # other user information from user_df
  user_id = user_df['id'][0]
  ids_user_blacklist = user_df['ids_user_blacklist'][0]
  user_cat_interests = user_df['user_interests'][0]
  user_id_interests = user_df['user_ids_of_interest'][0]
  # categorical data for what user is interested in
  user_cat_data_all = product_df[product_df['id'].isin(user_id_interests)]['categories']


  # TF-IDF COSINE SIMILARITIES FOR DESCRIPTIONS
  # fit matrix similarity matrix
  tf = TfidfVectorizer(analyzer='word',
                        stop_words='english')
  tfidf_matrix = tf.fit_transform(desc_df['description'])
  # get cosine similarity between first row and all other rows (ids)
  cosine_similarities_tfidf = linear_kernel(tfidf_matrix[0:1], tfidf_matrix)
  # get the cosine similarities ignoring user (will be 1)
  cosine_sims_prods_tfidf = cosine_similarities_tfidf.flatten()[1:]


  # COUNTVECTORIZER COSINE SIMILARITIES FOR METADATASOUP
  # fit CountVectorizer model
  countV = CountVectorizer(stop_words='english')
  count_matrix = countV.fit_transform(meta_df['metadata_soup'])
  # get cosine similairty between rows
  cosine_sim_soup = cosine_similarity(count_matrix[0:1], count_matrix)
  # get the cosine similarities ignoring user (will be 1)
  cosine_sim_soup = cosine_sim_soup.flatten()[1:]


  # COMBINE COSINE SIMILARITY (with specified weights)
  cosine_sim_combi = \
  ((cosine_sims_prods_tfidf * desc_weight) + (cosine_sim_soup * meta_weight)) / (desc_weight + meta_weight)


  # RETRIEVE RECOMMENDED PRODUCTS
  # get top n_prods of sorted similarites accounting for those which will be removed by user blacklist
  # --> (i.e. + blacklist's length)
  prods_to_get = n_prods + len(ids_user_blacklist) + 1
  top_nprods = cosine_sim_combi.argsort()[:-prods_to_get:-1]
  # get item ids from product data
  recommended_ids = product_df.iloc[top_nprods]['id']
  # remove blacklisted 
  recommended_prodids_blrmvd = recommended_ids[~recommended_ids.isin(ids_user_blacklist)].tolist()
  # return only the top n_prods most similar after removing blacklisted ids 
  recommended_prodids_blrmvd = [str(i) for i in recommended_prodids_blrmvd[0:n_prods]]


  # RETRIEVE RECOMMENDED CATEGORIES 
  # get count of categories from user interested ids
  cat_counts = collections.Counter(user_cat_data_all.sum())
  # get top n_cats categories from above
  recommended_cats = [i[0] for i in cat_counts.most_common(n_cats)]
  # if there are less than n_cats categpores append a random choice from the users intrested categories 
  if len(recommended_cats) < n_cats:
    n_cats_toadd = n_cats - len(recommended_cats) # how many categories should we add 
    recommended_cats = list(set(recommended_cats + random.choices(user_cat_interests, k=n_cats_toadd)))
  

  # OUTPUT DICT FOR THIS USER
  user_data = {'userid' : str(user_id),
              'recommended_prods':  recommended_prodids_blrmvd,
              'recommended_cats': recommended_cats}


  return(user_data)



#%%
"""
Test - compare user data to recomendations
"""

# RECOMMENDATIONS FOR USER WITH ABOVE FUNCTION
recommend = personalised_recommendation(product_df, user_df)

# COMPARE USER ID CATEGORIES AND RECOMMENDED
# user
usr_cat = product_df[product_df['id'].isin(user_df['user_ids_of_interest'][0])]['categories']
# recommended
rec_cat = recommend['recommended_cats']

# COMPARE USER ID PRODUCTS AND RECOMMENDED
# user
usr_prod = data[data.id.isin(user_df['user_ids_of_interest'][0])][['id','title','overview','tagline','keywords','genres']]
# recommended 
rec_prod = data[data.id.isin(recommend['recommended_prods'])][['title','overview','tagline','keywords','genres']]
