# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 09:01:33 2020

@author: Christoph
"""

#%% PACKAGES
from user_recommendation_api_configs import *
    
# create app
app = FastAPI(openapi_tags=tags_metadata)
    
# endpoint
@app.get(API_CONFIGS['API_ENDPOINT'],
         response_model = user_recommendation_Out,
         status_code=200,
         tags = ['Recommendation'])
async def User_Recommendation(userId: str):
    # find the recommendations for this user ID in MongoDB
    response = db_coll.find_one({'_id': userId})
    # handle if this user is not found 
    if response is None:
        print('error: user not found, returning default prods and cats')
        response = {}
        response['_id'] = userId
        response['recommended_prods'] = predefined_prodlist
        response['recommended_cats'] = predefined_catlist
        
    response['userId'] = response.pop('_id')
    print(response)

    # return recommendations
    return response
    

# check api environment
@app.get('/showenviron',
         tags = ['Environment'])
def Show_Environment():
    return os.environ

