# -*- coding: utf-8 -*-
"""
Created on Tue Jul 21 14:07:00 2020

@author: Christoph
"""

# Packages
import os
import uvicorn
import dns
from fastapi import FastAPI, Query, Path, BackgroundTasks, Form, File, UploadFile,Body
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from pymongo import MongoClient
from bson.objectid import ObjectId
import numpy as np


# Configs
API_CONFIGS = {
    'API_ENDPOINT':os.getenv('API_ENDPOINT','/user_prodcat_recommendation'),
    'MONGOURI':os.getenv('MONGOURI','mongodb+srv://ChrisTesting:ChrisTesting123@cwktest.anhok.gcp.mongodb.net/<dbname>?retryWrites=true&w=majority'),
    }

# load pre defined lists, incase user cannot be found in recommendation list    
predefined_prodlist = np.loadtxt('resources/predefined_prodlist.txt', str).tolist()
predefined_catlist = np.loadtxt('resources/predefined_catlist.txt', str).tolist()

# open MongoDB connection 
client = MongoClient(API_CONFIGS['MONGOURI'])
db_coll = client['E20MP']['user_recommendations']

    
# class for output
class user_recommendation_Out(BaseModel):
    userId : str 
    recommended_prods: List[str]
    recommended_cats: List[str]
    
# meta data for documentation
tags_metadata = [
    {
     "name": 'Recommendation',
     "title": "User recommendations",
     "description": "API for recommending products and categories to an individual user",
     "version": "0.0.0", 
    },
    {
        "name": "Environment",
        "title": "Show environment",
        "description": "Show all defined variables in environment",
    },
]

