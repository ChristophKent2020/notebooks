# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 09:07:08 2020

@author: Christoph
"""

# connect to MongoDB and collection
client = MongoClient(API_CONFIGS['MONGOURI'])
db = client['E20MP']
db_coll = db['user_recommendations']

# data to add to collection
to_add = [{'_id': 'abc@hotmail.com',
 'recommended_prods': ['85242',
  '24163',
  '41209',
  '15745',
  '17133',
  '55448',
  '28704',
  '36405',
  '22314',
  '44877',
  '15071',
  '37821',
  '41283',
  '32924',
  '30349',
  '26715',
  '13572',
  '7288',
  '18290',
  '16941'],
 'recommended_cats': ['drama', 'thriller', 'animation', 'adventure', 'action']},
 {'_id': 'def@hotmail.com',
 'recommended_prods': ['85242',
  '24163',
  '41209',
  '15745',
  '17133',
  '55448',
  '28704',
  '36405',
  '22314',
  '44877',
  '15071',
  '37821',
  '41283',
  '32924',
  '30349',
  '26715',
  '13572',
  '7288',
  '18290',
  '16941'],
 'recommended_cats': ['drama', 'thriller', 'animation', 'adventure', 'action']},
 {'_id': 'ghi@hotmail.com',
 'recommended_prods': ['85242',
  '24163',
  '41209',
  '15745',
  '17133',
  '55448',
  '28704',
  '36405',
  '22314',
  '44877',
  '15071',
  '37821',
  '41283',
  '32924',
  '30349',
  '26715',
  '13572',
  '7288',
  '18290',
  '16941'],
 'recommended_cats': ['fashion', 'books', 'clothes', 'adventure', 'action']}]
 
# remove all entries
db_coll.delete_many({})
# update all entries
db_coll.insert_many(to_add)
