# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 09:01:33 2020

@author: Christoph
"""

#%% PACKAGES
from product_recommendation_api_configs import *
    
# create app
app = FastAPI(openapi_tags=tags_metadata)
    
# endpoint
@app.get(API_CONFIGS['API_ENDPOINT'],
         response_model = product_recommendation_Out,
         status_code=200,
         tags = ['Recommendation'])
async def Product_Recommendation(productId: str, n_prods: int):
    # find the recommendations for this user ID in MongoDB
    product_similarity_data = db_coll.find_one({'_id': productId})
    
    # create similar prodcuts for response payload (if found, else give predefined list)
    try:
        similar_products = [j[1] for j in product_similarity_data['similar_prods']][0:n_prods]
    except:
        similar_products = predefined_prodlist[0:n_prods]

    response = {'productId':str(productId),
                'recommended_prods':similar_products}


    print(response)
    # return recommendations
    return response
    

# check api environment
@app.get('/showenviron',
         tags = ['Environment'])
def Show_Environment():
    return os.environ

