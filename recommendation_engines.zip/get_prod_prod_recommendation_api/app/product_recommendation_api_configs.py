# -*- coding: utf-8 -*-
"""
Created on Tue Jul 21 14:07:00 2020

@author: Christoph
"""

# Packages
import os
import uvicorn
import dns
from fastapi import FastAPI, Query, Path, BackgroundTasks, Form, File, UploadFile,Body
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from pymongo import MongoClient
from bson.objectid import ObjectId
import numpy as np


# Configs
API_CONFIGS = {
    'API_ENDPOINT':os.getenv('API_ENDPOINT','/prod_prod_recommendation'),
    'MONGOURI':os.getenv('MONGOURI','mongodb+srv://ChrisTesting:ChrisTesting123@cwktest.anhok.gcp.mongodb.net/<dbname>?retryWrites=true&w=majority'),
    }

# load pre defined list to default to (if error occours)
predefined_prodlist = np.loadtxt('resources/predefined_prodlist.txt', str).tolist()

# open MongoDB connection 
client = MongoClient(API_CONFIGS['MONGOURI'])
db_coll = client['E20MP']['product_recommendations']
    
# class for output
class product_recommendation_Out(BaseModel):
    productId : str 
    recommended_prods: List[str]
    
# meta data for documentation
tags_metadata = [
    {
     "name": 'Recommendation',
     "title": "Product recommendations",
     "description": "API for recommending products based on an individual product id",
    },
    {
        "name": "Environment",
        "title": "Show environment",
        "description": "Show all defined variables in environment",
    },
]

