# -*- coding: utf-8 -*-
"""
E20MP-contentbasedrecommendation-prodtoprod
### FUNCTION - model which combines both of the above ###
# Create & combine cosine similairity matrices for:
# 1) item description using TF-IDF 
# 2) item metadata soup using CountVectorizer
# weighting can be provided to give each to each similarity measure above, 
# as well as how many most similar products we want to return
"""

# import packages
import pandas as pd
import numpy as np
# for tfidf
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
# for countvectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# input directory 
input_dir = "C:/Users/Christoph/Documents/Python Scripts/E20MP_recommendation_engine/recommendation_engines/"


# import example data for prod to prod recommendation 
data = pd.read_csv(str(input_dir)+"/data/movies_metadata.csv", low_memory = False)
data_keywords = pd.read_csv(str(input_dir)+"/data/movies_keywords.csv", low_memory = False)
data_keywords.id = data_keywords.id.astype(str)
data = pd.merge(data, data_keywords, on ='id')
data.drop_duplicates('id')
data.drop_duplicates('id',inplace=True)

# import cleaned data frame required by model 
df_test = pd.read_csv(str(input_dir)+"/massaged_test_data/productdf_forrecomm_prodtoprod.csv")
df_test['description'] = df_test.description.str.lower() # make lower case
df_test = df_test[~df_test['description'].isnull()]
df_test.reset_index(drop=True, inplace=True)

def item_similarity(df, desc_weight, meta_weight, n_prods):
  '''
  # input: 
  1 - df with [id, long description, metadatasoup]
  2 - weight to give description-based similarity (dafult is desc_weight = 0.5)
  3 - weight to give metadata-based similarity (default is meta_weight = 0.5)
  4 - how many most similar products to return for each product (default is n_prods = 20)

  # output:
  # dictionary with id and 'n_prods' most similar product ids
  '''
  
  # TF-IDF COSINE SIMILARITIES FOR DESCRIPTIONS
  # fit TFIDF
  tf = TfidfVectorizer(analyzer='word',
                        stop_words='english')
  tfidf_matrix = tf.fit_transform(df['description'])
  # get cosine similarity between each row (ids)
  cosine_similarities_desc = linear_kernel(tfidf_matrix, tfidf_matrix)

  # COUNTVECTORIZER COSINE SIMILARITIES FOR METADATASOUP
  # fit CountVectorizer
  countV = CountVectorizer(stop_words='english')
  count_matrix = countV.fit_transform(df['metadata_soup'])
  cosine_sim_soup = cosine_similarity(count_matrix, count_matrix)

  # COMBINE COSINE SIMILARITY (with specified weights)
  cosine_sim_combi = \
  ((cosine_similarities_desc * desc_weight) + (cosine_sim_soup * meta_weight)) / (desc_weight + meta_weight)

  # DICTIONARY TO PROVIDE MOST SIMILAR n_prods per ID
  most_similar_prods_combi = []
  # get closest n_prods products for each product
  for idx in np.arange(0, cosine_sim_combi.shape[0],1):
    print(idx)
    # id of current product
    id_temp = df['id'][idx]
    # get n_prods most similar indices (note instance 0 will always be most similar)
    similar_indices = cosine_sim_combi[idx].argsort()[:-(n_prods+2):-1][1:]
    # get n_prods most similar items
    similar_items = [(cosine_sim_combi[idx][i], df['id'][i])
                    for i in similar_indices]
    # make into dict
    dict_to_append = {'_id': str(id_temp),'similar_prods':similar_items}
    
    # append to list of dicts
    most_similar_prods_combi.append(dict_to_append)
  
  return most_similar_prods_combi

#%% EXAMPLE
# e.g. of data
df_test.sample(5)

# run similarity algo
prod_similarity = item_similarity(df = df_test, desc_weight = 0.75, 
                                  meta_weight = 0.25, n_prods = 20)

# TEST COMPARISON - choose an id we want to get recommendations for
id_lookup = 10590 # e.g. this id is for 'we were soldiers' (about vietnam war)
id_lookup = 4918 # e.g. this id is for #'The fourth protocl' (Soviet agent, nuclear spy)
id_matches = prod_similarity[id_lookup]
id_ids = [str(i[1]) for i in id_matches]

# compare id data and matches
# with matched df
id_data_modinput = df_test[df_test.id == id_lookup]
matches_data_modinput = df_test[df_test.id.isin([int(i) for i in id_ids])]

# from actual data 
id_data_actualdata = data[data.id == str(id_lookup)]
matches_data_actualdata = data[data.id.isin(id_ids)]




